FANTASY_BASE_ENDPOINT = 'https://fantasy.espn.com/apis/v3/games/'

FANTASY_SPORTS = {
    'nfl' : 'ffl',
    'nba' : 'fba',
    'nhl' : 'fhl',
    'mlb' : 'flb',
    'wnba' : 'wfba'
}